import java.awt.*;

public interface Colecionavel {

    Image getImagem();
    int getPosicao();

}
