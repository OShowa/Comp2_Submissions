import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Pacotinho {

    private ArrayList<Colecionavel> figurinhasNoPacotinho = new ArrayList<>();

    public Pacotinho(Repositorio repo, int[] posicoesDesejadas) {

        for (int i = 0; i < posicoesDesejadas.length; i++) {
            this.figurinhasNoPacotinho.add(repo.getFigurinhaEspecifica(posicoesDesejadas[i]));
        }

        // ToDo IMPLEMENT ME!!!
    }

    /**
     * Produz um pacotinho com quantFigurinhas sorteadas aleatoriamente
     * dentre aqueles presentes no repositório informado.
     *
     * @param repo o repositório desejado
     * @param quantFigurinhas a quantidade de figurinhas a constar no pacotinho
     */
    public Pacotinho(Repositorio repo, int quantFigurinhas) {

        for (int i = 0; i < quantFigurinhas; i++) {

            Random random = new Random();
            int figurinhaAleatoria;

            figurinhaAleatoria = random.nextInt(repo.getTotalFigurinhas()) + 1;

            this.figurinhasNoPacotinho.add(repo.getFigurinhaEspecifica(figurinhaAleatoria));

        }

        // ToDo IMPLEMENT ME!!!
    }

    public Colecionavel[] getFigurinhas() {

        Colecionavel[] figurinhas = new Figurinha[figurinhasNoPacotinho.size()];

        for (int i = 0; i < figurinhasNoPacotinho.size(); i++) {
            figurinhas[i] = figurinhasNoPacotinho.get(i);
        }

        return figurinhas;  // ToDo IMPLEMENT ME!!!

    }
}
